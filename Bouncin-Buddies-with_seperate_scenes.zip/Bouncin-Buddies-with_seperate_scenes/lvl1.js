
  firstScene = new Phaser.Class({
    Extends: Phaser.Scene,
    initialize:
    function firstScene(){
        Phaser.Scene.call(this,{key:'firstScene'});
    },
    preload: function(){
        this.load.spritesheet('guy_red', 'assets/guy_spritesheet_red.png', { frameWidth: 366, frameHeight: 252});
        this.load.spritesheet('guy_blue', 'assets/guy_spritesheet_blue.png', { frameWidth: 366, frameHeight: 252});
        this.load.image('balloon', 'assets/balloon.png');
        //this.load.image('guy_red', 'assets/guy_idle_red.png');
        this.load.image('sky', 'assets/background_sky2d.png');
        this.load.image('platform', 'assets/platform_grass.png');
        this.load.image('ground', 'assets/foreground_grass.png');
        
        this.load.image('speedboost', 'assets/speedboost.png');
        this.load.image('coin', 'assets/coin.png');

        this.load.audio('bgmusic', ['assets/bgmusic.wav']);
        this.load.audio('jump', ['assets/jump.wav']);
        this.load.audio('error', ['assets/error.wav']);
        this.load.audio('bump', ['assets/bump.wav']);
        this.load.audio('pop', ['assets/pop.wav']);
        this.load.audio('balloonspawn', ['assets/balloonspawn.wav']);
        
    },
    create: function(){
        

            this.add.image(400, 300, 'sky');

            platforms = this.physics.add.staticGroup();

            platforms.create(400, 568, 'ground').setScale(1).refreshBody();

            platforms.create(700, 500, 'platform');
            platforms.create(75, 500, 'platform');

            player_red = this.physics.add.sprite(100, 375, 'guy_red').setScale(0.2);
            player_red.setBounce(0.1);
            player_red.setCollideWorldBounds(true);
            player_red.setGravityY(599);

            player_blue = this.physics.add.sprite(700, 375, 'guy_blue').setScale(0.2);
            player_blue.setBounce(0.1);
            player_blue.setCollideWorldBounds(true);
            player_blue.setGravityY(599);

            //loseText
            loseText = this.add.text(
                    400, 
                    200, 
                    "You Lose...lvl: 1", 
                    {
                        fontSize: 50,
                        color: "#000000",
                        fontStyle: "bold"
                    }
                ).setOrigin(0.5);

            loseText.visible = false;

            //red anims
            this.anims.create({
                key: 'red_idle',
                frames: [ { key: 'guy_red', frame: 0}],
                frameRate: 10,
                repeat: -1
            });
            this.anims.create({
                key: 'red_move',
                frames: [ { key: 'guy_red', frame: 1}],
                frameRate: 10,
                repeat: -1
            });
            this.anims.create({
                key: 'red_jump',
                frames: [ { key: 'guy_red', frame: 2}],
                frameRate: 10,
                repeat: -1
            });
            //blue anims
            this.anims.create({
                key: 'blue_idle',
                frames: [ { key: 'guy_blue', frame: 0}],
                frameRate: 10,
                repeat: -1
            });
            this.anims.create({
                key: 'blue_move',
                frames: [ { key: 'guy_blue', frame: 1}],
                frameRate: 10,
                repeat: -1
            });
            this.anims.create({
                key: 'blue_jump',
                frames: [ { key: 'guy_blue', frame: 2}],
                frameRate: 10,
                repeat: -1
            });

            //audio
            bgmusic = this.sound.add('bgmusic', {loop: true});
            bgmusic.play();
            popSFX = this.sound.add('pop', {loop: false});
            bump = this.sound.add('bump', {loop: false}, {volume: 0.2});
            error = this.sound.add('error', {loop: false});
            jump = this.sound.add('jump', {loop: false});
            balloonSpawn = this.sound.add('balloonspawn', {loop: false});

            //Create Balloon Timer
            timer = this.time.addEvent({
                delay: 5000,
                callback: spawnBalloon,
                loop: true
            });
        
            //create powerup timer
            powerupSpawnTimer = this.time.addEvent({
                delay: 15000,
                callback: spawnPowerup,
                loop: true
            });
            

            //balloon group
            balloons = this.physics.add.group({
                key: 'balloon',
                repeat: 0,
                setXY: {x: 12, y: 0, stepX: 70},
                mass: 0.3
            });
            
            balloons.children.iterate(function(child){
                child.setScale(0.5);
                child.setVelocity(Phaser.Math.Between(-200, 200), 20);
                child.setMass(0.3);
                child.allowGravity = true;
                child.setBounce(0.2);
                child.setGravityY(1);
                child.useDamping = true;
                child.allowDrag = true;
                child.allowRotation = true;
                child.setAngularAcceleration(1);
                child.isCircle = true;
                child.setCircle(20);
                child.setMaxSpeed = 2;

                child.setCollideWorldBounds(true);
            })
        
            //speedboost group
            speedboosts = this.physics.add.group({
                key: 'speedboost',
                repeat: 0,
                setXY: {x: 12, y: 0, stepX: 70},
                mass: 0.3
            });

            speedboosts.children.iterate(function(child){
                child.setScale(0.02);
                child.setVelocity(Phaser.Math.Between(-200, 200), 20);
                child.setMass(0.3);
                child.allowGravity = true;
                child.setBounce(0.2);
                child.setGravityY(1);
                child.useDamping = true;
                child.allowDrag = true;
                child.allowRotation = true;
                child.setAngularAcceleration(1);
                child.isCircle = true;
                child.setCircle(20);
                child.setMaxSpeed = 2;

                child.setCollideWorldBounds(true); 
            })
        
            //coin group
            coins = this.physics.add.group({
                key: 'coin',
                repeat: 0,
                setXY: {x: 12, y: 0, stepX: 70},
                mass: 0.3
            });
        
            coins.children.iterate(function(child){
                child.setScale(0.2);
                child.setVelocity(Phaser.Math.Between(-200, 200), 20);
                child.setMass(0.3);
                child.allowGravity = true;
                child.setBounce(0.2);
                child.setGravityY(1);
                child.useDamping = true;
                child.allowDrag = true;
                child.allowRotation = true;
                child.setAngularAcceleration(1);
                child.isCircle = true;
                child.setCircle(20);
                child.setMaxSpeed = 2;

                child.setCollideWorldBounds(true);
            })

            //text
            scoreText = this.add.text(16,16, 'Score: 0', {fontSize: '32px', fill: '#000'}); 

            //Collide Player with Platforms
            this.physics.add.collider(player_red, platforms);
            this.physics.add.collider(player_blue, platforms);
        
            //balloons and powerups collide with platforms
            this.physics.add.collider(balloons, platforms, popBalloon, null, this);
            this.physics.add.collider(speedboosts, platforms);
            this.physics.add.collider(coins, platforms);
            

            //player colliders with balloons
            this.physics.add.collider(player_red, balloons, hitBalloon, null, this);
            this.physics.add.collider(player_blue, balloons, hitBalloon, null, this);
        
            //player colliders with speedboost
            this.physics.add.collider(player_red, speedboosts, speedBoost, null, this);
            this.physics.add.collider(player_blue, speedboosts, speedBoost, null, this);
                
            //player colliders with coin
            this.physics.add.collider(player_red, coins, coinGet, null, this);
            this.physics.add.collider(player_blue, coins, coinGet, null, this);

            //let balloons collide with each other
            //this.physics.add.collider(balloons, balloons);

            // Input Events
            cursors = this.input.keyboard.createCursorKeys();


            //Second Player Keys
            keys = this.input.keyboard.addKeys('A,W,S,D,space');


    },
    update: function(){
        if(lost == true){
            if(keys.space.isDown){
                
                this.scene.start('levelselect')
            }
        }
        playerMovement();
    }
});
